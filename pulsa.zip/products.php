<?php
require_once 'config.php';
require_once 'database.php';
require_once 'includes/auth.php';

$auth = new Auth();
$auth->requireLogin();
$user = $auth->getCurrentUser();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produk - Dashboard Konter Pulsa</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">
                    <i class="fas fa-mobile-alt"></i>
                </div>
                <div class="sidebar-title">Konter Pulsa</div>
                <div class="sidebar-subtitle">Dashboard</div>
            </div>
            
            <nav class="sidebar-nav">
                <div class="nav-item">
                    <a href="dashboard.php" class="nav-link">
                        <i class="fas fa-tachometer-alt"></i>
                        Dashboard
                    </a>
                </div>
                <div class="nav-item">
                    <a href="products.php" class="nav-link active">
                        <i class="fas fa-box"></i>
                        Produk
                    </a>
                </div>
                <div class="nav-item">
                    <a href="stock.php" class="nav-link">
                        <i class="fas fa-warehouse"></i>
                        Stok
                    </a>
                </div>
                <div class="nav-item">
                    <a href="transactions.php" class="nav-link">
                        <i class="fas fa-exchange-alt"></i>
                        Transaksi
                    </a>
                </div>
                <div class="nav-item">
                    <a href="reports.php" class="nav-link">
                        <i class="fas fa-chart-bar"></i>
                        Laporan
                    </a>
                </div>
                <?php if ($auth->isAdmin()): ?>
                <div class="nav-item">
                    <a href="users.php" class="nav-link">
                        <i class="fas fa-users"></i>
                        Pengguna
                    </a>
                </div>
                <div class="nav-item">
                    <a href="settings.php" class="nav-link">
                        <i class="fas fa-cog"></i>
                        Pengaturan
                    </a>
                </div>
                <?php endif; ?>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Header -->
            <header class="header">
                <div class="header-left">
                    <button class="sidebar-toggle" onclick="toggleSidebar()">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h1 class="header-title">Manajemen Produk</h1>
                </div>
                
                <div class="header-actions">
                    <button class="btn btn-primary" onclick="openAddProductModal()">
                        <i class="fas fa-plus"></i> Tambah Produk
                    </button>
                    <div class="user-menu" onclick="toggleUserMenu()">
                        <div class="user-avatar">
                            <?= strtoupper(substr($user['full_name'], 0, 1)) ?>
                        </div>
                        <div class="user-info">
                            <div class="user-name"><?= htmlspecialchars($user['full_name']) ?></div>
                            <div class="user-role"><?= ucfirst($user['role']) ?></div>
                        </div>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    
                    <div class="user-dropdown" id="userDropdown">
                        <a href="profile.php" class="dropdown-item">
                            <i class="fas fa-user"></i>
                            Profil
                        </a>
                        <a href="#" onclick="logout()" class="dropdown-item">
                            <i class="fas fa-sign-out-alt"></i>
                            Keluar
                        </a>
                    </div>
                </div>
            </header>

            <!-- Products Content -->
            <div class="products-content">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Daftar Produk</h3>
                        <div class="card-actions">
                            <input type="text" id="productSearch" placeholder="Cari produk..." class="form-control">
                        </div>
                    </div>
                    <div class="card-body">
                        <div id="productList">
                            <!-- Product list will be loaded here -->
                        </div>
                        <div class="pagination" id="productPagination">
                            <!-- Pagination will be loaded here -->
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Add/Edit Product Modal -->
    <div id="productModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 id="modalTitle">Tambah Produk Baru</h3>
                <button class="modal-close" onclick="hideModal('productModal')">&times;</button>
            </div>
            <div class="modal-body">
                <form id="productForm">
                    <input type="hidden" id="productId">
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="providerId">Provider</label>
                            <select id="providerId" name="provider_id" class="form-control" required>
                                <!-- Providers will be loaded here -->
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="categoryId">Kategori</label>
                            <select id="categoryId" name="category_id" class="form-control" required>
                                <!-- Categories will be loaded here -->
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="productName">Nama Produk</label>
                            <input type="text" id="productName" name="name" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="productCode">Kode Produk (Opsional)</label>
                            <input type="text" id="productCode" name="code" class="form-control">
                        </div>
                        <div class="form-group">
                            <label for="quota">Kuota</label>
                            <input type="text" id="quota" name="quota" class="form-control" placeholder="Contoh: 1GB, Unlimited" required>
                        </div>
                        <div class="form-group">
                            <label for="validityDays">Masa Aktif (Hari)</label>
                            <input type="number" id="validityDays" name="validity_days" class="form-control" min="1">
                        </div>
                        <div class="form-group">
                            <label for="buyPrice">Harga Beli</label>
                            <input type="number" id="buyPrice" name="buy_price" class="form-control" step="0.01" required>
                        </div>
                        <div class="form-group">
                            <label for="sellPrice">Harga Jual</label>
                            <input type="number" id="sellPrice" name="sell_price" class="form-control" step="0.01" required>
                        </div>
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select id="status" name="status" class="form-control">
                                <option value="active">Aktif</option>
                                <option value="inactive">Tidak Aktif</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="description">Deskripsi</label>
                        <textarea id="description" name="description" class="form-control" rows="3"></textarea>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" onclick="hideModal('productModal')">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan Produk</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Loading Overlay -->
    <div id="loadingOverlay" class="loading-overlay">
        <div class="loading-spinner">
            <div class="spinner"></div>
            <p>Memuat data...</p>
        </div>
    </div>

    <!-- Scripts -->
    <script src="assets/js/auth.js"></script>
    <script src="assets/js/dashboard.js"></script>
    <script>
        let currentPage = 1;
        const productsPerPage = 10;

        document.addEventListener("DOMContentLoaded", function() {
            loadProducts();
            loadProvidersAndCategories();

            document.getElementById("productForm").addEventListener("submit", handleProductFormSubmit);
            document.getElementById("productSearch").addEventListener("keyup", function(event) {
                if (event.key === "Enter") {
                    loadProducts(1);
                }
            });
        });

        async function loadProducts(page = 1) {
            showLoading();
            currentPage = page;
            try {
                const response = await api.getProducts(currentPage, productsPerPage);
                if (response && response.success) {
                    renderProductList(response.data.products);
                    renderPagination(response.data.pagination);
                } else {
                    showNotification("Gagal memuat daftar produk", "error");
                }
            } catch (error) {
                console.error("Error loading products:", error);
                showNotification("Terjadi kesalahan saat memuat produk", "error");
            } finally {
                hideLoading();
            }
        }

        function renderProductList(products) {
            const productListDiv = document.getElementById("productList");
            if (products.length === 0) {
                productListDiv.innerHTML = "<div class=\"no-data\">Tidak ada produk ditemukan.</div>";
                return;
            }

            const columns = [
                { title: "Nama Produk", key: "name" },
                { title: "Provider", key: "provider_name" },
                { title: "Kategori", key: "category_name" },
                { title: "Kuota", key: "quota" },
                { title: "Harga Beli", key: "buy_price", format: (value) => formatCurrency(value) },
                { title: "Harga Jual", key: "sell_price", format: (value) => formatCurrency(value) },
                { title: "Stok", key: "quantity", format: (value, row) => `${value} ${getStockStatusBadge(value, row.min_stock, row.max_stock)}` },
                { title: "Status", key: "status", format: (value) => `<span class="badge badge-${value === 'active' ? 'success' : 'danger'}">${value.toUpperCase()}</span>` },
                { 
                    title: "Aksi", 
                    key: "actions", 
                    format: (value, row) => `
                        <button class="btn btn-sm btn-info" onclick="openEditProductModal(${row.id})"><i class="fas fa-edit"></i></button>
                        <button class="btn btn-sm btn-danger" onclick="deleteProduct(${row.id})"><i class="fas fa-trash"></i></button>
                    ` 
                }
            ];
            createTable(products, columns, "productList");
        }

        function renderPagination(pagination) {
            const paginationDiv = document.getElementById("productPagination");
            let paginationHtml = '';

            if (pagination.total_pages > 1) {
                paginationHtml += `<button class="btn btn-sm btn-secondary" ${!pagination.has_prev ? 'disabled' : ''} onclick="loadProducts(${pagination.prev_page})">Sebelumnya</button>`;
                for (let i = 1; i <= pagination.total_pages; i++) {
                    paginationHtml += `<button class="btn btn-sm btn-secondary ${i === pagination.current_page ? 'active' : ''}" onclick="loadProducts(${i})">${i}</button>`;
                }
                paginationHtml += `<button class="btn btn-sm btn-secondary" ${!pagination.has_next ? 'disabled' : ''} onclick="loadProducts(${pagination.next_page})">Selanjutnya</button>`;
            }
            paginationDiv.innerHTML = paginationHtml;
        }

        async function loadProvidersAndCategories() {
            try {
                const providersResponse = await api.request('/providers'); // Assuming you have a /providers endpoint
                const categoriesResponse = await api.request('/categories'); // Assuming you have a /categories endpoint

                if (providersResponse && providersResponse.success) {
                    const providerSelect = document.getElementById('providerId');
                    providerSelect.innerHTML = '<option value="">Pilih Provider</option>';
                    providersResponse.data.forEach(provider => {
                        providerSelect.innerHTML += `<option value="${provider.id}">${provider.name}</option>`;
                    });
                }

                if (categoriesResponse && categoriesResponse.success) {
                    const categorySelect = document.getElementById('categoryId');
                    categorySelect.innerHTML = '<option value="">Pilih Kategori</option>';
                    categoriesResponse.data.forEach(category => {
                        categorySelect.innerHTML += `<option value="${category.id}">${category.name}</option>`;
                    });
                }
            } catch (error) {
                console.error("Error loading providers/categories:", error);
                showNotification("Gagal memuat data provider dan kategori", "error");
            }
        }

        function openAddProductModal() {
            document.getElementById("modalTitle").textContent = "Tambah Produk Baru";
            document.getElementById("productForm").reset();
            document.getElementById("productId").value = "";
            showModal("productModal");
        }

        async function openEditProductModal(id) {
            showLoading();
            try {
                const response = await api.getProduct(id);
                if (response && response.success) {
                    const product = response.data;
                    document.getElementById("modalTitle").textContent = "Edit Produk";
                    document.getElementById("productId").value = product.id;
                    document.getElementById("providerId").value = product.provider_id;
                    document.getElementById("categoryId").value = product.category_id;
                    document.getElementById("productName").value = product.name;
                    document.getElementById("productCode").value = product.code;
                    document.getElementById("description").value = product.description;
                    document.getElementById("quota").value = product.quota;
                    document.getElementById("validityDays").value = product.validity_days;
                    document.getElementById("buyPrice").value = product.buy_price;
                    document.getElementById("sellPrice").value = product.sell_price;
                    document.getElementById("status").value = product.status;
                    showModal("productModal");
                } else {
                    showNotification("Gagal memuat data produk", "error");
                }
            } catch (error) {
                console.error("Error loading product for edit:", error);
                showNotification("Terjadi kesalahan saat memuat produk", "error");
            } finally {
                hideLoading();
            }
        }

        async function handleProductFormSubmit(event) {
            event.preventDefault();
            if (!validateForm("productForm")) {
                showNotification("Harap lengkapi semua kolom yang wajib diisi", "warning");
                return;
            }

            showLoading();
            const formData = new FormData(event.target);
            const productData = Object.fromEntries(formData.entries());

            // Convert prices and validity_days to numbers
            productData.buy_price = parseFloat(productData.buy_price);
            productData.sell_price = parseFloat(productData.sell_price);
            productData.validity_days = parseInt(productData.validity_days);

            const productId = document.getElementById("productId").value;
            let response;

            if (productId) {
                response = await api.updateProduct(productId, productData);
            } else {
                response = await api.createProduct(productData);
            }

            if (response && response.success) {
                showNotification(response.message, "success");
                hideModal("productModal");
                loadProducts(currentPage);
            } else {
                showNotification(response.error || "Terjadi kesalahan", "error");
            }
            hideLoading();
        }

        async function deleteProduct(id) {
            if (confirm("Apakah Anda yakin ingin menghapus produk ini?")) {
                showLoading();
                try {
                    const response = await api.deleteProduct(id);
                    if (response && response.success) {
                        showNotification(response.message, "success");
                        loadProducts(currentPage);
                    } else {
                        showNotification(response.error || "Gagal menghapus produk", "error");
                    }
                } catch (error) {
                    console.error("Error deleting product:", error);
                    showNotification("Terjadi kesalahan saat menghapus produk", "error");
                } finally {
                    hideLoading();
                }
            }
        }

        // Sidebar toggle for mobile
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('active');
        }

        // User menu toggle
        function toggleUserMenu() {
            const dropdown = document.getElementById('userDropdown');
            dropdown.classList.toggle('active');
        }

        // Close user menu when clicking outside
        document.addEventListener('click', function(e) {
            const userMenu = document.querySelector('.user-menu');
            const dropdown = document.getElementById('userDropdown');
            
            if (!userMenu.contains(e.target) && !dropdown.contains(e.target)) {
                dropdown.classList.remove('active');
            }
        });
    </script>
</body>
</html>

