<?php
require_once 'config.php';
require_once 'database.php';
require_once 'includes/auth.php';

$auth = new Auth();
$auth->requireLogin();
$user = $auth->getCurrentUser();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stok - Dashboard Konter Pulsa</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">
                    <i class="fas fa-mobile-alt"></i>
                </div>
                <div class="sidebar-title">Konter Pulsa</div>
                <div class="sidebar-subtitle">Dashboard</div>
            </div>
            
            <nav class="sidebar-nav">
                <div class="nav-item">
                    <a href="dashboard.php" class="nav-link">
                        <i class="fas fa-tachometer-alt"></i>
                        Dashboard
                    </a>
                </div>
                <div class="nav-item">
                    <a href="products.php" class="nav-link">
                        <i class="fas fa-box"></i>
                        Produk
                    </a>
                </div>
                <div class="nav-item">
                    <a href="stock.php" class="nav-link active">
                        <i class="fas fa-warehouse"></i>
                        Stok
                    </a>
                </div>
                <div class="nav-item">
                    <a href="transactions.php" class="nav-link">
                        <i class="fas fa-exchange-alt"></i>
                        Transaksi
                    </a>
                </div>
                <div class="nav-item">
                    <a href="reports.php" class="nav-link">
                        <i class="fas fa-chart-bar"></i>
                        Laporan
                    </a>
                </div>
                <?php if ($auth->isAdmin()): ?>
                <div class="nav-item">
                    <a href="users.php" class="nav-link">
                        <i class="fas fa-users"></i>
                        Pengguna
                    </a>
                </div>
                <div class="nav-item">
                    <a href="settings.php" class="nav-link">
                        <i class="fas fa-cog"></i>
                        Pengaturan
                    </a>
                </div>
                <?php endif; ?>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Header -->
            <header class="header">
                <div class="header-left">
                    <button class="sidebar-toggle" onclick="toggleSidebar()">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h1 class="header-title">Manajemen Stok</h1>
                </div>
                
                <div class="header-actions">
                    <button class="btn btn-primary" onclick="openStockInModal()">
                        <i class="fas fa-plus"></i> Stok Masuk
                    </button>
                    <button class="btn btn-warning" onclick="openStockOutModal()">
                        <i class="fas fa-minus"></i> Stok Keluar
                    </button>
                    <button class="btn btn-info" onclick="openAdjustStockModal()">
                        <i class="fas fa-sync-alt"></i> Sesuaikan Stok
                    </button>
                    <div class="user-menu" onclick="toggleUserMenu()">
                        <div class="user-avatar">
                            <?= strtoupper(substr($user["full_name"], 0, 1)) ?>
                        </div>
                        <div class="user-info">
                            <div class="user-name"><?= htmlspecialchars($user["full_name"]) ?></div>
                            <div class="user-role"><?= ucfirst($user["role"]) ?></div>
                        </div>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    
                    <div class="user-dropdown" id="userDropdown">
                        <a href="profile.php" class="dropdown-item">
                            <i class="fas fa-user"></i>
                            Profil
                        </a>
                        <a href="#" onclick="logout()" class="dropdown-item">
                            <i class="fas fa-sign-out-alt"></i>
                            Keluar
                        </a>
                    </div>
                </div>
            </header>

            <!-- Stock Content -->
            <div class="stock-content">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Ringkasan Stok</h3>
                        <div class="card-actions">
                            <input type="text" id="stockSearch" placeholder="Cari produk..." class="form-control">
                        </div>
                    </div>
                    <div class="card-body">
                        <div id="stockList">
                            <!-- Stock list will be loaded here -->
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Stock In Modal -->
    <div id="stockInModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Stok Masuk</h3>
                <button class="modal-close" onclick="hideModal(\'stockInModal\')">&times;</button>
            </div>
            <div class="modal-body">
                <form id="stockInForm">
                    <div class="form-group">
                        <label for="stockInProductId">Produk</label>
                        <select id="stockInProductId" name="product_id" class="form-control" required>
                            <!-- Products will be loaded here -->
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="stockInQuantity">Jumlah</label>
                        <input type="number" id="stockInQuantity" name="quantity" class="form-control" min="1" required>
                    </div>
                    <div class="form-group">
                        <label for="stockInBuyPrice">Harga Beli Satuan</label>
                        <input type="number" id="stockInBuyPrice" name="buy_price" class="form-control" step="0.01" required>
                    </div>
                    <div class="form-group">
                        <label for="stockInSupplier">Supplier</label>
                        <input type="text" id="stockInSupplier" name="supplier" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="stockInInvoice">Nomor Invoice</label>
                        <input type="text" id="stockInInvoice" name="invoice_number" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="stockInNotes">Catatan</label>
                        <textarea id="stockInNotes" name="notes" class="form-control" rows="3"></textarea>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" onclick="hideModal(\'stockInModal\')">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Stock Out Modal -->
    <div id="stockOutModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Stok Keluar</h3>
                <button class="modal-close" onclick="hideModal(\'stockOutModal\')">&times;</button>
            </div>
            <div class="modal-body">
                <form id="stockOutForm">
                    <div class="form-group">
                        <label for="stockOutProductId">Produk</label>
                        <select id="stockOutProductId" name="product_id" class="form-control" required>
                            <!-- Products will be loaded here -->
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="stockOutQuantity">Jumlah</label>
                        <input type="number" id="stockOutQuantity" name="quantity" class="form-control" min="1" required>
                    </div>
                    <div class="form-group">
                        <label for="stockOutSellPrice">Harga Jual Satuan</label>
                        <input type="number" id="stockOutSellPrice" name="sell_price" class="form-control" step="0.01" required>
                    </div>
                    <div class="form-group">
                        <label for="stockOutCustomerName">Nama Pelanggan</label>
                        <input type="text" id="stockOutCustomerName" name="customer_name" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="stockOutCustomerPhone">Telepon Pelanggan</label>
                        <input type="text" id="stockOutCustomerPhone" name="customer_phone" class="form-control">
                    </div>
                    <div class="form-group">
                        <label for="stockOutPaymentMethod">Metode Pembayaran</label>
                        <select id="stockOutPaymentMethod" name="payment_method" class="form-control">
                            <option value="cash">Tunai</option>
                            <option value="transfer">Transfer</option>
                            <option value="ewallet">E-Wallet</option>
                            <option value="credit">Kredit</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="stockOutNotes">Catatan</label>
                        <textarea id="stockOutNotes" name="notes" class="form-control" rows="3"></textarea>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" onclick="hideModal(\'stockOutModal\')">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Adjust Stock Modal -->
    <div id="adjustStockModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>Sesuaikan Stok</h3>
                <button class="modal-close" onclick="hideModal(\'adjustStockModal\')">&times;</button>
            </div>
            <div class="modal-body">
                <form id="adjustStockForm">
                    <div class="form-group">
                        <label for="adjustProductId">Produk</label>
                        <select id="adjustProductId" name="product_id" class="form-control" required>
                            <!-- Products will be loaded here -->
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="adjustQuantity">Jumlah Stok Baru</label>
                        <input type="number" id="adjustQuantity" name="quantity" class="form-control" min="0" required>
                    </div>
                    <div class="form-group">
                        <label for="adjustNotes">Catatan Penyesuaian</label>
                        <textarea id="adjustNotes" name="notes" class="form-control" rows="3"></textarea>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" onclick="hideModal(\'adjustStockModal\')">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan Penyesuaian</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Loading Overlay -->
    <div id="loadingOverlay" class="loading-overlay">
        <div class="loading-spinner">
            <div class="spinner"></div>
            <p>Memuat data...</p>
        </div>
    </div>

    <!-- Scripts -->
    <script src="assets/js/auth.js"></script>
    <script src="assets/js/dashboard.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            loadStockSummary();
            loadProductsForModals();

            document.getElementById("stockInForm").addEventListener("submit", handleStockInSubmit);
            document.getElementById("stockOutForm").addEventListener("submit", handleStockOutSubmit);
            document.getElementById("adjustStockForm").addEventListener("submit", handleAdjustStockSubmit);

            document.getElementById("stockSearch").addEventListener("keyup", function(event) {
                if (event.key === "Enter") {
                    loadStockSummary();
                }
            });
        });

        async function loadStockSummary() {
            showLoading();
            try {
                const response = await api.getStockSummary();
                if (response && response.success) {
                    renderStockList(response.data);
                } else {
                    showNotification("Gagal memuat ringkasan stok", "error");
                }
            } catch (error) {
                console.error("Error loading stock summary:", error);
                showNotification("Terjadi kesalahan saat memuat stok", "error");
            } finally {
                hideLoading();
            }
        }

        function renderStockList(stockData) {
            const stockListDiv = document.getElementById("stockList");
            if (stockData.length === 0) {
                stockListDiv.innerHTML = "<div class=\"no-data\">Tidak ada data stok ditemukan.</div>";
                return;
            }

            const columns = [
                { title: "Produk", key: "product_name" },
                { title: "Provider", key: "provider_name" },
                { title: "Kategori", key: "category_name" },
                { title: "Stok", key: "quantity", format: (value, row) => `${value} ${getStockStatusBadge(value, row.min_stock, row.max_stock)}` },
                { title: "Harga Beli", key: "buy_price", format: (value) => formatCurrency(value) },
                { title: "Harga Jual", key: "sell_price", format: (value) => formatCurrency(value) },
                { title: "Nilai Stok", key: "stock_value", format: (value) => formatCurrency(value) },
                { 
                    title: "Aksi", 
                    key: "actions", 
                    format: (value, row) => `
                        <button class="btn btn-sm btn-info" onclick="viewStockMovements(${row.id})"><i class="fas fa-history"></i></button>
                        <button class="btn btn-sm btn-secondary" onclick="openStockSettingsModal(${row.id})"><i class="fas fa-cog"></i></button>
                    ` 
                }
            ];
            createTable(stockData, columns, "stockList");
        }

        async function loadProductsForModals() {
            try {
                const response = await api.getProducts(1, 9999); // Load all products
                if (response && response.success) {
                    const products = response.data.products;
                    const stockInSelect = document.getElementById("stockInProductId");
                    const stockOutSelect = document.getElementById("stockOutProductId");
                    const adjustSelect = document.getElementById("adjustProductId");

                    stockInSelect.innerHTML = 
                        stockOutSelect.innerHTML = 
                        adjustSelect.innerHTML = 
                        "<option value=\"\">Pilih Produk</option>";

                    products.forEach(product => {
                        const option = `<option value="${product.id}">${product.name} (${product.provider_name})</option>`;
                        stockInSelect.innerHTML += option;
                        stockOutSelect.innerHTML += option;
                        adjustSelect.innerHTML += option;
                    });
                }
            } catch (error) {
                console.error("Error loading products for modals:", error);
                showNotification("Gagal memuat daftar produk untuk form", "error");
            }
        }

        function openStockInModal() {
            document.getElementById("stockInForm").reset();
            showModal("stockInModal");
        }

        function openStockOutModal() {
            document.getElementById("stockOutForm").reset();
            showModal("stockOutModal");
        }

        function openAdjustStockModal() {
            document.getElementById("adjustStockForm").reset();
            showModal("adjustStockModal");
        }

        async function handleStockInSubmit(event) {
            event.preventDefault();
            if (!validateForm("stockInForm")) {
                showNotification("Harap lengkapi semua kolom yang wajib diisi", "warning");
                return;
            }

            showLoading();
            const formData = new FormData(event.target);
            const data = Object.fromEntries(formData.entries());
            data.quantity = parseInt(data.quantity);
            data.buy_price = parseFloat(data.buy_price);

            try {
                const response = await api.stockIn(data);
                if (response && response.success) {
                    showNotification(response.message, "success");
                    hideModal("stockInModal");
                    loadStockSummary();
                } else {
                    showNotification(response.error || "Gagal menambahkan stok masuk", "error");
                }
            } catch (error) {
                console.error("Error stock in:", error);
                showNotification("Terjadi kesalahan saat memproses stok masuk", "error");
            } finally {
                hideLoading();
            }
        }

        async function handleStockOutSubmit(event) {
            event.preventDefault();
            if (!validateForm("stockOutForm")) {
                showNotification("Harap lengkapi semua kolom yang wajib diisi", "warning");
                return;
            }

            showLoading();
            const formData = new FormData(event.target);
            const data = Object.fromEntries(formData.entries());
            data.quantity = parseInt(data.quantity);
            data.sell_price = parseFloat(data.sell_price);

            try {
                const response = await api.stockOut(data);
                if (response && response.success) {
                    showNotification(response.message, "success");
                    hideModal("stockOutModal");
                    loadStockSummary();
                } else {
                    showNotification(response.error || "Gagal memproses stok keluar", "error");
                }
            } catch (error) {
                console.error("Error stock out:", error);
                showNotification("Terjadi kesalahan saat memproses stok keluar", "error");
            } finally {
                hideLoading();
            }
        }

        async function handleAdjustStockSubmit(event) {
            event.preventDefault();
            if (!validateForm("adjustStockForm")) {
                showNotification("Harap lengkapi semua kolom yang wajib diisi", "warning");
                return;
            }

            showLoading();
            const formData = new FormData(event.target);
            const data = Object.fromEntries(formData.entries());
            data.product_id = parseInt(data.product_id);
            data.quantity = parseInt(data.quantity);

            try {
                const response = await api.adjustStock(data);
                if (response && response.success) {
                    showNotification(response.message, "success");
                    hideModal("adjustStockModal");
                    loadStockSummary();
                } else {
                    showNotification(response.error || "Gagal menyesuaikan stok", "error");
                }
            } catch (error) {
                console.error("Error adjusting stock:", error);
                showNotification("Terjadi kesalahan saat menyesuaikan stok", "error");
            } finally {
                hideLoading();
            }
        }

        async function viewStockMovements(productId) {
            // Implement logic to show stock movements, maybe in a new modal or page
            showNotification(`Melihat pergerakan stok untuk Produk ID: ${productId}`, "info");
            // Example: const response = await api.request(`/stock/movements/${productId}`);
        }

        async function openStockSettingsModal(productId) {
            // Implement logic to open modal for stock min/max settings
            showNotification(`Membuka pengaturan stok untuk Produk ID: ${productId}`, "info");
            // Example: const product = await api.getProduct(productId);
            // Populate form and show modal
        }

        // Sidebar toggle for mobile
        function toggleSidebar() {
            const sidebar = document.getElementById(\'sidebar\');
            sidebar.classList.toggle(\'active\');
        }

        // User menu toggle
        function toggleUserMenu() {
            const dropdown = document.getElementById(\'userDropdown\');
            dropdown.classList.toggle(\'active\');
        }

        // Close user menu when clicking outside
        document.addEventListener(\'click\', function(e) {
            const userMenu = document.querySelector(\'.user-menu\');
            const dropdown = document.getElementById(\'userDropdown\');
            
            if (!userMenu.contains(e.target) && !dropdown.contains(e.target)) {
                dropdown.classList.remove(\'active\');
            }
        });
    </script>
</body>
</html>

