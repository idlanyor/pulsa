<?php
require_once 'config.php';
require_once 'database.php';
require_once 'includes/auth.php';

$auth = new Auth();
$auth->requireLogin();
$user = $auth->getCurrentUser();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaksi - Dashboard Konter Pulsa</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">
                    <i class="fas fa-mobile-alt"></i>
                </div>
                <div class="sidebar-title">Konter Pulsa</div>
                <div class="sidebar-subtitle">Dashboard</div>
            </div>
            
            <nav class="sidebar-nav">
                <div class="nav-item">
                    <a href="dashboard.php" class="nav-link">
                        <i class="fas fa-tachometer-alt"></i>
                        Dashboard
                    </a>
                </div>
                <div class="nav-item">
                    <a href="products.php" class="nav-link">
                        <i class="fas fa-box"></i>
                        Produk
                    </a>
                </div>
                <div class="nav-item">
                    <a href="stock.php" class="nav-link">
                        <i class="fas fa-warehouse"></i>
                        Stok
                    </a>
                </div>
                <div class="nav-item">
                    <a href="transactions.php" class="nav-link active">
                        <i class="fas fa-exchange-alt"></i>
                        Transaksi
                    </a>
                </div>
                <div class="nav-item">
                    <a href="reports.php" class="nav-link">
                        <i class="fas fa-chart-bar"></i>
                        Laporan
                    </a>
                </div>
                <?php if ($auth->isAdmin()): ?>
                <div class="nav-item">
                    <a href="users.php" class="nav-link">
                        <i class="fas fa-users"></i>
                        Pengguna
                    </a>
                </div>
                <div class="nav-item">
                    <a href="settings.php" class="nav-link">
                        <i class="fas fa-cog"></i>
                        Pengaturan
                    </a>
                </div>
                <?php endif; ?>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Header -->
            <header class="header">
                <div class="header-left">
                    <button class="sidebar-toggle" onclick="toggleSidebar()">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h1 class="header-title">Manajemen Transaksi</h1>
                </div>
                
                <div class="header-actions">
                    <div class="user-menu" onclick="toggleUserMenu()">
                        <div class="user-avatar">
                            <?= strtoupper(substr($user["full_name"], 0, 1)) ?>
                        </div>
                        <div class="user-info">
                            <div class="user-name"><?= htmlspecialchars($user["full_name"]) ?></div>
                            <div class="user-role"><?= ucfirst($user["role"]) ?></div>
                        </div>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    
                    <div class="user-dropdown" id="userDropdown">
                        <a href="profile.php" class="dropdown-item">
                            <i class="fas fa-user"></i>
                            Profil
                        </a>
                        <a href="#" onclick="logout()" class="dropdown-item">
                            <i class="fas fa-sign-out-alt"></i>
                            Keluar
                        </a>
                    </div>
                </div>
            </header>

            <!-- Transactions Content -->
            <div class="transactions-content">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Transaksi Masuk (Pembelian)</h3>
                        <div class="card-actions">
                            <input type="date" id="stockInDateFrom" class="form-control">
                            <input type="date" id="stockInDateTo" class="form-control">
                            <button class="btn btn-primary" onclick="loadStockInTransactions()">Filter</button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div id="stockInList">
                            <!-- Stock In list will be loaded here -->
                        </div>
                        <div class="pagination" id="stockInPagination">
                            <!-- Pagination will be loaded here -->
                        </div>
                    </div>
                </div>

                <div class="card mt-20">
                    <div class="card-header">
                        <h3 class="card-title">Transaksi Keluar (Penjualan)</h3>
                        <div class="card-actions">
                            <input type="date" id="stockOutDateFrom" class="form-control">
                            <input type="date" id="stockOutDateTo" class="form-control">
                            <button class="btn btn-primary" onclick="loadStockOutTransactions()">Filter</button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div id="stockOutList">
                            <!-- Stock Out list will be loaded here -->
                        </div>
                        <div class="pagination" id="stockOutPagination">
                            <!-- Pagination will be loaded here -->
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Loading Overlay -->
    <div id="loadingOverlay" class="loading-overlay">
        <div class="loading-spinner">
            <div class="spinner"></div>
            <p>Memuat data...</p>
        </div>
    </div>

    <!-- Scripts -->
    <script src="assets/js/auth.js"></script>
    <script src="assets/js/dashboard.js"></script>
    <script>
        let currentStockInPage = 1;
        let currentStockOutPage = 1;
        const transactionsPerPage = 10;

        document.addEventListener("DOMContentLoaded", function() {
            loadStockInTransactions();
            loadStockOutTransactions();
        });

        async function loadStockInTransactions(page = 1) {
            showLoading();
            currentStockInPage = page;
            try {
                const dateFrom = document.getElementById("stockInDateFrom").value;
                const dateTo = document.getElementById("stockInDateTo").value;
                const filters = { date_from: dateFrom, date_to: dateTo };

                const response = await api.getStockInTransactions(currentStockInPage, transactionsPerPage, filters);
                if (response && response.success) {
                    renderStockInList(response.data);
                    // Pagination for stock in needs to be implemented based on total records
                } else {
                    showNotification("Gagal memuat transaksi masuk", "error");
                }
            } catch (error) {
                console.error("Error loading stock in transactions:", error);
                showNotification("Terjadi kesalahan saat memuat transaksi masuk", "error");
            } finally {
                hideLoading();
            }
        }

        function renderStockInList(transactions) {
            const stockInListDiv = document.getElementById("stockInList");
            if (transactions.length === 0) {
                stockInListDiv.innerHTML = "<div class=\"no-data\">Tidak ada transaksi masuk ditemukan.</div>";
                return;
            }

            const columns = [
                { title: "Tanggal", key: "transaction_date", format: (value) => formatDate(value) },
                { title: "Produk", key: "product_name" },
                { title: "Provider", key: "provider_name" },
                { title: "Jumlah", key: "quantity" },
                { title: "Harga Beli", key: "buy_price", format: (value) => formatCurrency(value) },
                { title: "Total Biaya", key: "total_cost", format: (value) => formatCurrency(value) },
                { title: "Supplier", key: "supplier" },
                { title: "Invoice", key: "invoice_number" }
            ];
            createTable(transactions, columns, "stockInList");
        }

        async function loadStockOutTransactions(page = 1) {
            showLoading();
            currentStockOutPage = page;
            try {
                const dateFrom = document.getElementById("stockOutDateFrom").value;
                const dateTo = document.getElementById("stockOutDateTo").value;
                const filters = { date_from: dateFrom, date_to: dateTo };

                const response = await api.getStockOutTransactions(currentStockOutPage, transactionsPerPage, filters);
                if (response && response.success) {
                    renderStockOutList(response.data);
                    // Pagination for stock out needs to be implemented based on total records
                } else {
                    showNotification("Gagal memuat transaksi keluar", "error");
                }
            } catch (error) {
                console.error("Error loading stock out transactions:", error);
                showNotification("Terjadi kesalahan saat memuat transaksi keluar", "error");
            } finally {
                hideLoading();
            }
        }

        function renderStockOutList(transactions) {
            const stockOutListDiv = document.getElementById("stockOutList");
            if (transactions.length === 0) {
                stockOutListDiv.innerHTML = "<div class=\"no-data\">Tidak ada transaksi keluar ditemukan.</div>";
                return;
            }

            const columns = [
                { title: "Tanggal", key: "transaction_date", format: (value) => formatDate(value) },
                { title: "Produk", key: "product_name" },
                { title: "Provider", key: "provider_name" },
                { title: "Jumlah", key: "quantity" },
                { title: "Harga Jual", key: "sell_price", format: (value) => formatCurrency(value) },
                { title: "Total Pendapatan", key: "total_revenue", format: (value) => formatCurrency(value) },
                { title: "Pelanggan", key: "customer_name" },
                { title: "Metode Bayar", key: "payment_method" }
            ];
            createTable(transactions, columns, "stockOutList");
        }

        // Sidebar toggle for mobile
        function toggleSidebar() {
            const sidebar = document.getElementById(\'sidebar\');
            sidebar.classList.toggle(\'active\');
        }

        // User menu toggle
        function toggleUserMenu() {
            const dropdown = document.getElementById(\'userDropdown\');
            dropdown.classList.toggle(\'active\');
        }

        // Close user menu when clicking outside
        document.addEventListener(\'click\', function(e) {
            const userMenu = document.querySelector(\'.user-menu\');
            const dropdown = document.getElementById(\'userDropdown\');
            
            if (!userMenu.contains(e.target) && !dropdown.contains(e.target)) {
                dropdown.classList.remove(\'active\');
            }
        });
    </script>
</body>
</html>

