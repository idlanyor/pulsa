<?php
require_once 'config.php';
require_once 'database.php';
require_once 'includes/auth.php';

$auth = new Auth();
$auth->requireAdmin(); // Only admin can access this page
$user = $auth->getCurrentUser();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pengaturan - Dashboard Konter Pulsa</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body>
    <div class="dashboard">
        <!-- Sidebar -->
        <aside class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">
                    <i class="fas fa-mobile-alt"></i>
                </div>
                <div class="sidebar-title">Konter Pulsa</div>
                <div class="sidebar-subtitle">Dashboard</div>
            </div>
            
            <nav class="sidebar-nav">
                <div class="nav-item">
                    <a href="dashboard.php" class="nav-link">
                        <i class="fas fa-tachometer-alt"></i>
                        Dashboard
                    </a>
                </div>
                <div class="nav-item">
                    <a href="products.php" class="nav-link">
                        <i class="fas fa-box"></i>
                        Produk
                    </a>
                </div>
                <div class="nav-item">
                    <a href="stock.php" class="nav-link">
                        <i class="fas fa-warehouse"></i>
                        Stok
                    </a>
                </div>
                <div class="nav-item">
                    <a href="transactions.php" class="nav-link">
                        <i class="fas fa-exchange-alt"></i>
                        Transaksi
                    </a>
                </div>
                <div class="nav-item">
                    <a href="reports.php" class="nav-link">
                        <i class="fas fa-chart-bar"></i>
                        Laporan
                    </a>
                </div>
                <?php if ($auth->isAdmin()): ?>
                <div class="nav-item">
                    <a href="users.php" class="nav-link">
                        <i class="fas fa-users"></i>
                        Pengguna
                    </a>
                </div>
                <div class="nav-item">
                    <a href="settings.php" class="nav-link active">
                        <i class="fas fa-cog"></i>
                        Pengaturan
                    </a>
                </div>
                <?php endif; ?>
            </nav>
        </aside>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Header -->
            <header class="header">
                <div class="header-left">
                    <button class="sidebar-toggle" onclick="toggleSidebar()">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h1 class="header-title">Pengaturan Aplikasi</h1>
                </div>
                
                <div class="header-actions">
                    <div class="user-menu" onclick="toggleUserMenu()">
                        <div class="user-avatar">
                            <?= strtoupper(substr($user['full_name'], 0, 1)) ?>
                        </div>
                        <div class="user-info">
                            <div class="user-name"><?= htmlspecialchars($user['full_name']) ?></div>
                            <div class="user-role"><?= ucfirst($user['role']) ?></div>
                        </div>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    
                    <div class="user-dropdown" id="userDropdown">
                        <a href="profile.php" class="dropdown-item">
                            <i class="fas fa-user"></i>
                            Profil
                        </a>
                        <a href="#" onclick="logout()" class="dropdown-item">
                            <i class="fas fa-sign-out-alt"></i>
                            Keluar
                        </a>
                    </div>
                </div>
            </header>

            <!-- Settings Content -->
            <div class="settings-content">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Pengaturan Umum</h3>
                    </div>
                    <div class="card-body">
                        <form id="generalSettingsForm">
                            <div class="form-group">
                                <label for="appName">Nama Aplikasi</label>
                                <input type="text" id="appName" name="app_name" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="currencySymbol">Simbol Mata Uang</label>
                                <input type="text" id="currencySymbol" name="currency_symbol" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="minStockThreshold">Ambang Batas Stok Minimum</label>
                                <input type="number" id="minStockThreshold" name="min_stock_threshold" class="form-control" min="0" required>
                            </div>
                            <div class="form-group">
                                <label for="maxStockThreshold">Ambang Batas Stok Maksimum</label>
                                <input type="number" id="maxStockThreshold" name="max_stock_threshold" class="form-control" min="0" required>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Simpan Pengaturan</button>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="card mt-20">
                    <div class="card-header">
                        <h3 class="card-title">Pengaturan Database</h3>
                    </div>
                    <div class="card-body">
                        <form id="databaseSettingsForm">
                            <div class="form-group">
                                <label for="dbHost">Host Database</label>
                                <input type="text" id="dbHost" name="db_host" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="dbName">Nama Database</label>
                                <input type="text" id="dbName" name="db_name" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="dbUser">User Database</label>
                                <input type="text" id="dbUser" name="db_user" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="dbPass">Password Database</label>
                                <input type="password" id="dbPass" name="db_pass" class="form-control">
                                <small class="form-text text-muted">Kosongkan jika tidak ingin mengubah password.</small>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Simpan Pengaturan Database</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Loading Overlay -->
    <div id="loadingOverlay" class="loading-overlay">
        <div class="loading-spinner">
            <div class="spinner"></div>
            <p>Memuat data...</p>
        </div>
    </div>

    <!-- Scripts -->
    <script src="assets/js/auth.js"></script>
    <script src="assets/js/dashboard.js"></script>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            loadSettings();
            document.getElementById("generalSettingsForm").addEventListener("submit", handleGeneralSettingsSubmit);
            document.getElementById("databaseSettingsForm").addEventListener("submit", handleDatabaseSettingsSubmit);
        });

        async function loadSettings() {
            showLoading();
            try {
                // Assuming you have an API endpoint for settings
                const response = await api.request("/settings"); 
                if (response && response.success) {
                    const settings = response.data;
                    document.getElementById("appName").value = settings.app_name || '';
                    document.getElementById("currencySymbol").value = settings.currency_symbol || '';
                    document.getElementById("minStockThreshold").value = settings.min_stock_threshold || 0;
                    document.getElementById("maxStockThreshold").value = settings.max_stock_threshold || 0;

                    // Database settings (sensitive, might not be exposed via API directly)
                    document.getElementById("dbHost").value = settings.db_host || '';
                    document.getElementById("dbName").value = settings.db_name || '';
                    document.getElementById("dbUser").value = settings.db_user || '';
                    // dbPass is intentionally not loaded for security reasons
                } else {
                    showNotification(response.error || "Gagal memuat pengaturan", "error");
                }
            } catch (error) {
                console.error("Error loading settings:", error);
                showNotification("Terjadi kesalahan saat memuat pengaturan", "error");
            } finally {
                hideLoading();
            }
        }

        async function handleGeneralSettingsSubmit(event) {
            event.preventDefault();
            if (!validateForm("generalSettingsForm")) {
                showNotification("Harap lengkapi semua kolom yang wajib diisi", "warning");
                return;
            }

            showLoading();
            const formData = new FormData(event.target);
            const settingsData = Object.fromEntries(formData.entries());

            try {
                // Assuming you have an API endpoint for updating general settings
                const response = await api.request("/settings/general", {
                    method: "PUT",
                    body: JSON.stringify(settingsData)
                });
                if (response && response.success) {
                    showNotification(response.message, "success");
                } else {
                    showNotification(response.error || "Gagal menyimpan pengaturan umum", "error");
                }
            } catch (error) {
                console.error("Error saving general settings:", error);
                showNotification("Terjadi kesalahan saat menyimpan pengaturan umum", "error");
            } finally {
                hideLoading();
            }
        }

        async function handleDatabaseSettingsSubmit(event) {
            event.preventDefault();
            if (!validateForm("databaseSettingsForm")) {
                showNotification("Harap lengkapi semua kolom yang wajib diisi", "warning");
                return;
            }

            showLoading();
            const formData = new FormData(event.target);
            const dbSettingsData = Object.fromEntries(formData.entries());

            try {
                // Assuming you have an API endpoint for updating database settings
                const response = await api.request("/settings/database", {
                    method: "PUT",
                    body: JSON.stringify(dbSettingsData)
                });
                if (response && response.success) {
                    showNotification(response.message, "success");
                } else {
                    showNotification(response.error || "Gagal menyimpan pengaturan database", "error");
                }
            } catch (error) {
                console.error("Error saving database settings:", error);
                showNotification("Terjadi kesalahan saat menyimpan pengaturan database", "error");
            } finally {
                hideLoading();
            }
        }

        // Sidebar toggle for mobile
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('active');
        }

        // User menu toggle
        function toggleUserMenu() {
            const dropdown = document.getElementById('userDropdown');
            dropdown.classList.toggle('active');
        }

        // Close user menu when clicking outside
        document.addEventListener('click', function(e) {
            const userMenu = document.querySelector('.user-menu');
            const dropdown = document.getElementById('userDropdown');
            
            if (!userMenu.contains(e.target) && !dropdown.contains(e.target)) {
                dropdown.classList.remove('active');
            }
        });
    </script>
</body>
</html>

